(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// routes.js                                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Router.route('/', {                                                    // 1
    template: 'home'                                                   // 2
});                                                                    //
                                                                       //
Router.route('/home', {                                                // 5
    template: 'home'                                                   // 6
});                                                                    //
                                                                       //
Router.route('/newContact', {                                          // 9
    template: 'newContact'                                             // 10
});                                                                    //
                                                                       //
Router.route('/results/:ContactName', {                                // 13
    template: 'results',                                               // 14
    data: function () {                                                // 15
        var name = this.params.ContactName;                            // 16
        var results = Contacts.findOne({ name: name });                // 17
        return results;                                                // 18
    }                                                                  //
});                                                                    //
                                                                       //
Router.route('/resulta/:ContactName', {                                // 22
    template: 'results',                                               // 23
    data: function () {                                                // 24
        var name = this.params.ContactName;                            // 25
        var results = Contacts.findOne({ name: name });                // 26
        return results;                                                // 27
    }                                                                  //
});                                                                    //
                                                                       //
Router.route('/resultu/:ContactName', {                                // 31
    template: 'results',                                               // 32
    data: function () {                                                // 33
        var name = this.params.ContactName;                            // 34
        var results = Contacts.findOne({ lastname: name });            // 35
        return results;                                                // 36
    }                                                                  //
});                                                                    //
                                                                       //
Router.route('/search', {                                              // 40
    template: 'search'                                                 // 41
});                                                                    //
                                                                       //
Router.route('/searchFirstName', {                                     // 44
    template: 'searchFirstName'                                        // 45
});                                                                    //
                                                                       //
Router.route('/searchLastName', {                                      // 48
    template: 'searchLastName'                                         // 49
});                                                                    //
                                                                       //
Router.route('/view/:_id', {                                           // 52
    template: 'view',                                                  // 53
    data: function () {                                                // 54
        var person_id = this.params._id;                               // 55
        return Contacts.findOne({ _id: person_id });                   // 56
    }                                                                  //
});                                                                    //
                                                                       //
Router.route('/edit/:_id', {                                           // 60
    template: 'edit',                                                  // 61
    data: function () {                                                // 62
        var person_id = this.params._id;                               // 63
        return Contacts.findOne({ _id: person_id });                   // 64
    }                                                                  //
});                                                                    //
                                                                       //
Router.route('/delete/:_id', {                                         // 68
    template: 'delete',                                                // 69
    data: function () {                                                // 70
        var person_id = this.params._id;                               // 71
        Contacts.remove({ _id: person_id });                           // 72
        Router.go('/');                                                // 73
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=routes.js.map
