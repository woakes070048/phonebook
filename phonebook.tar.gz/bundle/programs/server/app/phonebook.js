(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// phonebook.js                                                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Contacts = new Meteor.Collection('contacts');                          // 1
                                                                       //
if (Meteor.isClient) {                                                 // 3
  Template.contacts.helpers({                                          // 4
    'contact': function () {                                           // 5
      return Contacts.find();                                          // 6
    }                                                                  //
  });                                                                  //
                                                                       //
  Meteor.startup(function () {                                         // 10
    GoogleMaps.load();                                                 // 11
  });                                                                  //
                                                                       //
  Template.map.helpers({                                               // 14
    mapOptions: function () {                                          // 15
      if (GoogleMaps.loaded()) {                                       // 16
        return {                                                       // 17
          center: new google.maps.LatLng(-37.8136, 144.9631),          // 18
          zoom: 8                                                      // 19
        };                                                             //
      }                                                                //
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.addContact.events({                                         // 25
    'click .btn': function (event) {                                   // 26
      event.preventDefault();                                          // 27
      var ContactName = $('[name="ContactName"]').val();               // 28
      var Name = $('[name="LastName"]').val();                         // 29
      var number = $('[name="number"]').val();                         // 30
      var email = $('[name="email"]').val();                           // 31
      var long = $('[name="Longitude"]').val();                        // 32
      var lat = $('[name="Latitude"]').val();                          // 33
      Contacts.insert({                                                // 34
        name: ContactName,                                             // 35
        lastname: Name,                                                // 36
        number: number,                                                // 37
        email: email,                                                  // 38
        long: long,                                                    // 39
        lat: lat,                                                      // 40
        createdAt: new Date()                                          // 41
      });                                                              //
      $('[name="ContactName"]').val('');                               // 43
      $('[name="LastName"]').val('');                                  // 44
      $('[name="email"]').val('');                                     // 45
      $('[name="number"]').val('');                                    // 46
      $('[name="Longitude"]').val('');                                 // 47
      $('[name="Latitude"]').val('');                                  // 48
                                                                       //
      Router.go('/');                                                  // 50
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.search.events({                                             // 54
    'submit form': function (event) {                                  // 55
      event.preventDefault();                                          // 56
      var ContactName = $('[name="keyword"]').val();                   // 57
      //  var reply = Contacts.find({"name":"Amit"});                  //
      $('[name="ContactName"]').val('');                               // 59
                                                                       //
      Router.go('/results/' + ContactName);                            // 61
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.searchFirstName.events({                                    // 65
    'submit form': function (event) {                                  // 66
      event.preventDefault();                                          // 67
      var ContactName = $('[name="Name"]').val();                      // 68
      //  var reply = Contacts.find({"name":"Amit"});                  //
      $('[name="Name"]').val('');                                      // 70
                                                                       //
      Router.go('/resulta/' + ContactName);                            // 72
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.searchLastName.events({                                     // 76
    'submit form': function (event) {                                  // 77
      event.preventDefault();                                          // 78
      var ContactName = $('[name="Name"]').val();                      // 79
      //  var reply = Contacts.find({"name":"Amit"});                  //
      $('[name="Name"]').val('');                                      // 81
                                                                       //
      Router.go('/resultu/' + ContactName);                            // 83
    }                                                                  //
  });                                                                  //
                                                                       //
  Template.edit.events({                                               // 87
    'submit form': function (event) {                                  // 88
      event.preventDefault();                                          // 89
      var ContactName = $('[name="ContactName"]').val();               // 90
      console.log(this._id);                                           // 91
                                                                       //
      Contacts.update({ _id: this._id }, { $set: { name: ContactName } });
                                                                       //
      $('[name="ContactName"]').val('');                               // 95
                                                                       //
      Router.go('/');                                                  // 97
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
if (Meteor.isServer) {}                                                // 102
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=phonebook.js.map
