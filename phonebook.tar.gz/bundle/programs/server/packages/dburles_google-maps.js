(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var _ = Package.underscore._;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['dburles:google-maps'] = {};

})();

//# sourceMappingURL=dburles_google-maps.js.map
